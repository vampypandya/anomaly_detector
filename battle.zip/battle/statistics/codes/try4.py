from __future__ import division
import numpy

import matplotlib.pyplot as plt


# Sample Dataset
x = [10, 9, 13, 14, 15,8, 9, 10, 11, 12, 9, 0, 8, 8, 25,9,11,10]
plt.subplot(311)
plt.plot(x,color='g')
# Median absolute deviation
def mad(data, axis=None):
    return numpy.mean(numpy.abs(data - numpy.mean(data, axis)), axis)
_mad = numpy.abs(x - numpy.median(x)) / mad(x)

# Standard deviation
_sd = numpy.abs(x - numpy.mean(x)) / numpy.std(x)

print _mad
plt.subplot(312)
plt.plot(_mad,color='r')

for t in _mad:
	if(t-min(_mad)>1.5):
		
		plt.annotate('local max', xy=(_mad.tolist().index(t), t), xytext=(5, 4),
			    arrowprops=dict(facecolor='black', shrink=0.05),
			    )

plt.show()
