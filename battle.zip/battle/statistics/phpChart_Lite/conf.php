<?php
define('SCRIPTPATH', str_replace(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])),'', str_replace('\\', '/',dirname(__FILE__))).'/');
define('DEBUG', false);





/******** DO NOT MODIFY ***********/
require_once('phpChart.php');     
/**********************************/
?>
