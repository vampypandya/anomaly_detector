<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->

<?php
require_once("phpChart_Lite/conf.php");
if(isset($_POST['submit'])){ 
	$descriptorspec = array(
	   0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
	   1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
	   2 => array("file", "./error-output.txt", "a") // stderr is a file to write to
	);
	$numb=$_POST['emp_no'];
	
	$process0 = proc_open('/usr/local/spark/bin/spark-submit try6.py "'.$numb.'"', $descriptorspec,$pipes);
	if (is_resource($process0)) {
		$answer =stream_get_contents($pipes[1]);
		  fclose($pipes[1]);
		  proc_close($process0);
	}

		
	//$command = escapeshellcmd('/home/vampy/miniconda2/bin/python try4.py');
//$output = shell_exec($command);
//	echo $output;
		exec("/home/vampy/miniconda2/bin/python try4.py");



	
}

?>
	<h1><center>Anomalous Behaviour </center></h1>
<img src="num1.png" width="100%" height="300" alt="My Company Name" title="My Company Name" align="center" hspace="5" vspace="5">