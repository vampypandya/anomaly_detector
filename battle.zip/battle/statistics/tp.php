<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->

<?php
require_once("phpChart_Lite/conf.php");

	$descriptorspec = array(
	   0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
	   1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
	   2 => array("file", "./error-output.txt", "a") // stderr is a file to write to
	);

	
	
	    $line1 = array(array('1/1/2006', 5), array('2/1/2006', 1), array('3/1/2006', 3), array('4/1/2006', 7));
    $line2 = array(array('1/1/2006', 2), array('2/1/2006', 6), array('3/1/2006', 4), array('4/1/2006', 3));
    
    $pc = new C_PhpChartX(array($line1,$line2),'chart1');

    $pc->set_legend(array('show'=>true,'location'=>'nw','yoffset'=>6));
    $pc->set_axes(array(
            'xaxis'=> array(
				
				'tickOptions'=> array('formatString'=>'%m.%y'),
				'ticks'=>array('12/1/2005', '1/1/2006', '2/1/2006', '3/1/2006', '4/1/2006', '5/1/2006'))
            ));
    $pc->draw(400,300);


?>
