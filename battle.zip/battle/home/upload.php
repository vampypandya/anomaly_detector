
<?php

include("../PHPLoginHash/config.php");
include('../PHPLoginHash/class/userClass.php');

require 'PHPExcel.php';
require_once 'PHPExcel/IOFactory.php';

$target_dir = "uploads/";
$target_file = $target_dir . "trial.xlsx";
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check=true;
    if($check !== false) {
       
        $uploadOk = 1;
    } else {
        echo "Error, See logs for further details";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Error, See logs for further details";
    $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "xls" && $imageFileType != "xlsx" && $imageFileType != "csv" ) {
    echo "Error, See logs for further details";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        
	chmod("uploads/trial.xlsx",0777);
	$path="uploads/trial.xlsx";
	
	
	$objPHPExcel = PHPExcel_IOFactory::load($path);
	foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
	    $worksheetTitle     = $worksheet->getTitle();
	    $highestRow         = $worksheet->getHighestRow(); // e.g. 10
	    $highestColumn      = $worksheet->getHighestColumn(); // e.g 'F'
	    $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);
	    $nrColumns = ord($highestColumn) - 64;
	    
	   

	    for ($row = 1; $row <= $highestRow; ++ $row) {
		
		for ($col = 0; $col < $highestColumnIndex; ++ $col) {
		    $cell = $worksheet->getCellByColumnAndRow($col, $row);
		    $val = $cell->getValue();
		    $dataType = PHPExcel_Cell_DataType::dataTypeForValue($val);
		    
		}
	    }
	break;
	   
	}

	for ($row = 2; $row <= $highestRow; ++ $row) {
	    $val=array();
	for ($col = 0; $col < $highestColumnIndex; ++ $col) {
	   $cell = $worksheet->getCellByColumnAndRow($col, $row);
	   $val[] = $cell->getValue();
	}

	
	
	

	$db = getDB();
        $st = $db->prepare("INSERT INTO details(emp_no,swipe_date,time,status) VALUES (:emp_no,:swipe_date,:time,:status)");
        $st->bindParam("emp_no", $val[0],PDO::PARAM_STR);
	$st->bindParam("swipe_date", $val[1],PDO::PARAM_STR);
	$st->bindParam("time", $val[2],PDO::PARAM_STR);
	$st->bindParam("status", $val[3],PDO::PARAM_STR);
          
          
            
          
          $st->execute();
	$ress=shell_exec('python codes/exceltocsv.py uploads/trial.xlsx');
	
	break;
	}

	
	$url='/battle/home/index.php';
    	header("Location: $url");

    } else {
        echo "Error, See logs for further details";
    }
}

?>

