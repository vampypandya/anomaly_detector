import xlrd
import csv
import os
import sys

def csv_from_excel(f_name):

	wb = xlrd.open_workbook(f_name)
	sh = wb.sheet_by_name('Sheet1')
	your_csv_file = open('filey.csv', 'wb')
	wr = csv.writer(your_csv_file, quoting=csv.QUOTE_ALL)

	for rownum in xrange(sh.nrows):
		wr.writerow(sh.row_values(rownum))

	your_csv_file.close()
	os.system('python /opt/lampp/htdocs/battle/home/codes/csvtojson.py filey.csv')
	
csv_from_excel(sys.argv[1])
