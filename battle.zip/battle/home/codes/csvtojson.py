import csv
import json
import sys

f_name=sys.argv[1]

csvfile = open(f_name, 'r')
jsonfile = open('/opt/lampp/htdocs/battle/statistics/files/fil.json', 'w')

fieldnames = ("FirstName","LastName","IDNumber","Message")
reader = csv.DictReader( csvfile)
for row in reader:
    json.dump(row, jsonfile)
    jsonfile.write('\n')
